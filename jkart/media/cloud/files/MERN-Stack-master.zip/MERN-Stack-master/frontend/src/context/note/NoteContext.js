import { createContext } from "react";

// creating the context api
const NoteContext = createContext();

export default NoteContext;